var a04349 =
[
    [ "How to create your own project using OpenMesh", "a04348.html", null ],
    [ "First Steps - Building a cube", "a04336.html", null ],
    [ "Using iterators and circulators", "a04337.html", null ],
    [ "Using (custom) properties", "a04338.html", null ],
    [ "Using STL algorithms", "a04339.html", null ],
    [ "Using Smart Handles", "a04347.html", null ],
    [ "Using standard properties", "a04340.html", null ],
    [ "Using mesh attributes and traits", "a04341.html", null ],
    [ "Extending the mesh using traits", "a04342.html", null ],
    [ "Deleting geometry elements", "a04343.html", null ],
    [ "Using IO::Options", "a04344.html", null ],
    [ "Using custom properties (old style)", "a04345.html", null ],
    [ "Storing custom properties", "a04346.html", null ]
];