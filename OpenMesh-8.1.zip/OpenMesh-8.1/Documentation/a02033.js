var a02033 =
[
    [ "~BaseReader", "a02033.html#affd6cb98cb0883d0afc5edd2067b21fe", null ],
    [ "can_u_read", "a02033.html#ac507cba601d3c10bbbe4ed376d9f6628", null ],
    [ "check_extension", "a02033.html#a9be6726a28324b1b1af557ff483b4efd", null ],
    [ "get_description", "a02033.html#a845929e9dc345159b03b30eb3fbfe0aa", null ],
    [ "get_extensions", "a02033.html#a9e76bc7b1b46b7a8b4922d8ca5934419", null ],
    [ "get_magic", "a02033.html#ad89e93769bc1e41d8d465012e5c45512", null ],
    [ "read", "a02033.html#af4a32645528c1bf2043a9259b172f411", null ],
    [ "read", "a02033.html#a0fd4df36decf91cd91a7f363aae56065", null ]
];