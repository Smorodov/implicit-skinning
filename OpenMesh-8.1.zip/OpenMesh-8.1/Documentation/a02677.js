var a02677 =
[
    [ "Base", "a02677.html#a9296c24aebd1c87c71be6fb177b4528e", null ],
    [ "CollapseInfo", "a02677.html#a53c7d167d660d512d864a1f4e6a43149", null ],
    [ "EdgeHandle", "a02677.html#aca933991fbc250a445744fe55b8aaa7a", null ],
    [ "FaceHandle", "a02677.html#a0d15bd3f564575c0707c5d24542774a4", null ],
    [ "Handle", "a02677.html#a8553804a3615908b503e1081517a7fff", null ],
    [ "Mesh", "a02677.html#a283856c7df0fe3f0f7380fd2ef54dc78", null ],
    [ "Normal", "a02677.html#ab5a127bbc5af7d2ec291ff09404b0030", null ],
    [ "NormalCone", "a02677.html#a98bb326faf1d547f04dc44f8d8f6cd86", null ],
    [ "Point", "a02677.html#ac94465e11b99346c5be7796ddd5256e5", null ],
    [ "Scalar", "a02677.html#a9e85ab0725e6de3c6084cab601e3a8cc", null ],
    [ "Self", "a02677.html#a04b05531e502d42303cfaa546ffb191c", null ],
    [ "VertexHandle", "a02677.html#a959b268e3e9d11957fa748804a569454", null ],
    [ "ModNormalDeviationT", "a02677.html#a9ce9d2155ccb0c7719081d7e0ec2c023", null ],
    [ "~ModNormalDeviationT", "a02677.html#a598f31b76401fff7f03b1ade2ea8345a", null ],
    [ "collapse_priority", "a02677.html#aa199f3f2299fc171b332dc8fc59d543a", null ],
    [ "initialize", "a02677.html#a4149a3835595f38a97b5ba2cf5d14e23", null ],
    [ "name", "a02677.html#a3ed524f1fe28cdb787f6bad3e2637604", null ],
    [ "normal_deviation", "a02677.html#a1763b9ccf7233d0e066ec15eadfc1bc2", null ],
    [ "postprocess_collapse", "a02677.html#a06a7edc9ef58e548f823e8fb4549ac58", null ],
    [ "set_error_tolerance_factor", "a02677.html#a30869e4cdeabe62e162b75355863c415", null ],
    [ "set_normal_deviation", "a02677.html#a083312c66b27b936d28fceb86e32bc86", null ]
];