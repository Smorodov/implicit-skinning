var searchData=
[
  ['legal_5fcollapse',['LEGAL_COLLAPSE',['../a02661.html#a49500127c96591367298aa17e8527e44a2b521064f4abfdfb6eb5464308b6f6e7',1,'OpenMesh::Decimater::ModBaseT']]],
  ['locked',['LOCKED',['../a01238.html#af600bbf2c3f55c90a2a64848f0547617a665a2fb27301203c9c817123a49f9215',1,'OpenMesh::Attributes']]],
  ['lsb',['LSB',['../a02029.html#a9f4f797b08c045b611eaa6f8d149da21ac53f41d3b8306a764e7382372d56b7ec',1,'OpenMesh::IO::Options::LSB()'],['../a02501.html#a9ccf92afc560bd415eeeda60b4870042a6122652d3bc6c9f6c10cf9518a5f4e24',1,'OpenMesh::Endian::LSB()']]]
];
