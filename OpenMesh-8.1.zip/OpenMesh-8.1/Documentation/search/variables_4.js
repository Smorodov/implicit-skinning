var searchData=
[
  ['p0',['p0',['../a02633.html#a4d6e1b8c56453e3de48ed178d067c876',1,'OpenMesh::Decimater::CollapseInfoT']]],
  ['p1',['p1',['../a02633.html#a91226116d563790a8d04b09a9ef2d965',1,'OpenMesh::Decimater::CollapseInfoT']]]
];
