var searchData=
[
  ['qt_5fread_5ffilters',['qt_read_filters',['../a02025.html#a5a5b7314f7fcd4ac01374c2482e30661',1,'OpenMesh::IO::_IOManager_']]],
  ['qt_5fwrite_5ffilters',['qt_write_filters',['../a02025.html#a39f74c9e6c8e32ab44432bc0abc6676f',1,'OpenMesh::IO::_IOManager_']]],
  ['quadrict',['QuadricT',['../a01985.html#aa4dd04f39435110361e4088cc376618a',1,'OpenMesh::Geometry::QuadricT::QuadricT(Scalar _a, Scalar _b, Scalar _c, Scalar _d, Scalar _e, Scalar _f, Scalar _g, Scalar _h, Scalar _i, Scalar _j)'],['../a01985.html#ae6a410e0bd234af03477f8466d0b45d3',1,'OpenMesh::Geometry::QuadricT::QuadricT(Scalar _a=0.0, Scalar _b=0.0, Scalar _c=0.0, Scalar _d=0.0)']]]
];
