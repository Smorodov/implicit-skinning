var searchData=
[
  ['attributebits',['AttributeBits',['../a01238.html#ab78a93560926cd2f9958cb028f7ea96d',1,'OpenMesh::Attributes']]]
];
