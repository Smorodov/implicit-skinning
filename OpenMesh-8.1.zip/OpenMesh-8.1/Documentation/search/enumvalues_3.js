var searchData=
[
  ['edgecolor',['EdgeColor',['../a02029.html#a9f4f797b08c045b611eaa6f8d149da21af3c3df02714d44a4e46c5fbce90cc50f',1,'OpenMesh::IO::Options']]]
];
