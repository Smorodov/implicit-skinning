var searchData=
[
  ['notes_20on_20template_20programming',['Notes on template programming',['../a04319.html',1,'additional_information']]],
  ['naming_20conventions',['Naming Conventions',['../a04329.html',1,'additional_information']]]
];
