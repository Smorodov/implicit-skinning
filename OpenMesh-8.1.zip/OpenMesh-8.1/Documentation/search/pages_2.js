var searchData=
[
  ['deprecated_20list',['Deprecated List',['../a01227.html',1,'']]],
  ['deleting_20geometry_20elements',['Deleting geometry elements',['../a04343.html',1,'tutorial']]]
];
