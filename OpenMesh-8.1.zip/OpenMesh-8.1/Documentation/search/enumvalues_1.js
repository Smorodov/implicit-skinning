var searchData=
[
  ['color',['Color',['../a01238.html#ab78a93560926cd2f9958cb028f7ea96dad51534b15e5d0f65569251f4cb3c0d0c',1,'OpenMesh::Attributes']]],
  ['coloralpha',['ColorAlpha',['../a02029.html#a9f4f797b08c045b611eaa6f8d149da21ac2f73680b7d720b96efe6ea1199d5d4e',1,'OpenMesh::IO::Options']]],
  ['colorfloat',['ColorFloat',['../a02029.html#a9f4f797b08c045b611eaa6f8d149da21a1bc6e5b9faf304b2ad899896549cbd8c',1,'OpenMesh::IO::Options']]],
  ['custom',['Custom',['../a02029.html#a9f4f797b08c045b611eaa6f8d149da21afe46a936c0254f948d4f4d004d1d679f',1,'OpenMesh::IO::Options']]]
];
