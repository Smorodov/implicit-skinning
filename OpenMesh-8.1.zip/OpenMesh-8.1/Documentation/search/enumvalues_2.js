var searchData=
[
  ['default',['Default',['../a02029.html#a9f4f797b08c045b611eaa6f8d149da21a7e68f74f3e555a90cc6b3ea1b5fb42ac',1,'OpenMesh::IO::Options']]],
  ['deleted',['DELETED',['../a01238.html#af600bbf2c3f55c90a2a64848f0547617a7c61840f7e5e9b96c2a7b7ca7e0963d5',1,'OpenMesh::Attributes']]]
];
