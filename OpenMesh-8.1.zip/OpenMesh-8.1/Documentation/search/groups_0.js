var searchData=
[
  ['interface_20concepts',['Interface Concepts',['../a01231.html',1,'']]]
];
