var searchData=
[
  ['statusbits',['StatusBits',['../a01238.html#af600bbf2c3f55c90a2a64848f0547617',1,'OpenMesh::Attributes']]]
];
