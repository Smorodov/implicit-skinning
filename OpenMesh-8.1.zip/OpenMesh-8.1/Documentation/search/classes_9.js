var searchData=
[
  ['importert',['ImporterT',['../a02021.html',1,'OpenMesh::IO']]],
  ['info',['Info',['../a02689.html',1,'OpenMesh::Decimater::ModProgMeshT']]],
  ['interpolatingsqrt3lgt',['InterpolatingSqrt3LGT',['../a03045.html',1,'OpenMesh::Subdivider::Uniform']]],
  ['iteratort',['IteratorT',['../a02233.html',1,'']]],
  ['itraits',['ITraits',['../a02205.html',1,'OpenMesh::FinalMeshItemsT']]]
];
