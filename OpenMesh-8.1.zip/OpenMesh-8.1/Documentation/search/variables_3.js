var searchData=
[
  ['interface_5f',['interface_',['../a03073.html#afb629f999cdff18c71780372ffa4a655',1,'OpenMesh::Utils::HeapT']]],
  ['invalidedgehandle',['InvalidEdgeHandle',['../a02313.html#aa23384aa0cd664431ee2c22a9a01fc7d',1,'OpenMesh::PolyConnectivity']]],
  ['invalidfacehandle',['InvalidFaceHandle',['../a02313.html#a78014bea8d569ba1f07fc55ef1a4b19c',1,'OpenMesh::PolyConnectivity']]],
  ['invalidhalfedgehandle',['InvalidHalfedgeHandle',['../a02313.html#a28e271ca70ee579ff3532124147d7c61',1,'OpenMesh::PolyConnectivity']]],
  ['invalidvertexhandle',['InvalidVertexHandle',['../a02313.html#a986cacf0e6df55c72d12c2780ea38c96',1,'OpenMesh::PolyConnectivity']]]
];
