var searchData=
[
  ['illegal_5fcollapse',['ILLEGAL_COLLAPSE',['../a02661.html#a49500127c96591367298aa17e8527e44afc88837943f46ccbf0ef35d3fcf9c5b1',1,'OpenMesh::Decimater::ModBaseT']]]
];
