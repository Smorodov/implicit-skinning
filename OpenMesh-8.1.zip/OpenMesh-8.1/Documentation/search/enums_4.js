var searchData=
[
  ['type',['Type',['../a02501.html#a9ccf92afc560bd415eeeda60b4870042',1,'OpenMesh::Endian']]]
];
