var searchData=
[
  ['scalar',['Scalar',['../a01877.html#a1b4f707455d955241b14467f8bb053c0',1,'OpenMesh::Concepts::KernelT::Scalar()'],['../a02389.html#a15372f27edf521d8e9028e2abccae342',1,'OpenMesh::PolyMeshT::Scalar()']]],
  ['state_5ft',['state_t',['../a02869.html#a13c642f3a0e8bfb626e99d0d27b7fdd9',1,'OpenMesh::Subdivider::Adaptive::CompositeTraits::state_t()'],['../a01241.html#af706613543b0da1b097580a9dc30fc6e',1,'OpenMesh::Subdivider::Adaptive::state_t()']]]
];
