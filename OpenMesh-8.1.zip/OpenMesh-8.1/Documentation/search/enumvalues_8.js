var searchData=
[
  ['msb',['MSB',['../a02029.html#a9f4f797b08c045b611eaa6f8d149da21a5976f96b11378c06f15f99bef6cc5f19',1,'OpenMesh::IO::Options::MSB()'],['../a02501.html#a9ccf92afc560bd415eeeda60b4870042ac1f56fc0f17f4491229e17218ab557c0',1,'OpenMesh::Endian::MSB()']]]
];
