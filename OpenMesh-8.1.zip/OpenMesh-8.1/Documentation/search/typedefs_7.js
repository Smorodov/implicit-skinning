var searchData=
[
  ['normal',['Normal',['../a01877.html#ae4e2708d22ac0b5261e9c485475525fb',1,'OpenMesh::Concepts::KernelT::Normal()'],['../a02389.html#a3570fd132d1ac589b380485cf59c9e0b',1,'OpenMesh::PolyMeshT::Normal()'],['../a02469.html#ae1227753ac66ff36bc8e6322a9324bab',1,'OpenMesh::DefaultTraits::Normal()'],['../a02473.html#a611c09747ed8fb0985944e0601845c35',1,'OpenMesh::DefaultTraitsDouble::Normal()']]]
];
