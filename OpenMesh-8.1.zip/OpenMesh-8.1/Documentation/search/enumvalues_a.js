var searchData=
[
  ['prevhalfedge',['PrevHalfedge',['../a01238.html#ab78a93560926cd2f9958cb028f7ea96dafaaebe1808b5cce96ad4e19df471d58a',1,'OpenMesh::Attributes']]]
];
