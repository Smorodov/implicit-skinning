var searchData=
[
  ['fl',['fl',['../a02633.html#abe823726812c34c63eccc8316f5b1de5',1,'OpenMesh::Decimater::CollapseInfoT']]],
  ['fr',['fr',['../a02633.html#a2962fea162ba214fe7394d60ddb322d7',1,'OpenMesh::Decimater::CollapseInfoT']]]
];
