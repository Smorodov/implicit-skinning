var searchData=
[
  ['some_20words_20on_20the_20c_2b_2b_20implementation',['Some words on the C++ implementation',['../a04321.html',1,'additional_information']]],
  ['specifying_20an_20openmesh_20using_20eigen3_20vectors',['Specifying an OpenMesh using Eigen3 vectors',['../a04325.html',1,'mesh_docu']]],
  ['some_20basic_20operations_3a_20flipping_20and_20collapsing_20edges',['Some basic operations: Flipping and collapsing edges',['../a04331.html',1,'mesh_docu']]],
  ['some_20notes_20on_20how_20to_20speedup_20openmesh',['Some Notes on how to speedup OpenMesh',['../a04333.html',1,'additional_information']]],
  ['specifying_20your_20mymesh',['Specifying your MyMesh',['../a04324.html',1,'mesh_docu']]],
  ['smart_20tagger',['Smart Tagger',['../a04351.html',1,'tools_docu']]],
  ['smoother_20tools',['Smoother Tools',['../a04332.html',1,'tools_docu']]],
  ['sudivision_20tools',['Sudivision Tools',['../a04334.html',1,'tools_docu']]],
  ['storing_20custom_20properties',['Storing custom properties',['../a04346.html',1,'tutorial']]]
];
