var searchData=
[
  ['vertexcolor',['VertexColor',['../a02029.html#a9f4f797b08c045b611eaa6f8d149da21af7b6bb87f12fdfe5c9a8f8e1ce9325c7',1,'OpenMesh::IO::Options']]],
  ['vertexnormal',['VertexNormal',['../a02029.html#a9f4f797b08c045b611eaa6f8d149da21ad989c6d671050e12953b648c4c72dded',1,'OpenMesh::IO::Options']]],
  ['vertextexcoord',['VertexTexCoord',['../a02029.html#a9f4f797b08c045b611eaa6f8d149da21ae9e664738c4c48ac057770fb08a723f0',1,'OpenMesh::IO::Options']]]
];
