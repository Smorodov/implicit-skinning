var searchData=
[
  ['quadrict_2ehh',['QuadricT.hh',['../a00161.html',1,'']]]
];
