var searchData=
[
  ['kernelt',['KernelT',['../a01877.html',1,'OpenMesh::Concepts']]]
];
