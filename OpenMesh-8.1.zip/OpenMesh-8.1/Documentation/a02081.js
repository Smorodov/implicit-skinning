var a02081 =
[
    [ "Option", "a02081.html#a64e0d2f73712d56ed5f911c39664a641", null ],
    [ "~BaseWriter", "a02081.html#a7f287d4cf768bf1a0ee08ad68286fa1c", null ],
    [ "binary_size", "a02081.html#a8a6800a1bc26c06ea05ea672c6504351", null ],
    [ "can_u_write", "a02081.html#a0e250c7543862441dc6ac877b6f44ef9", null ],
    [ "check", "a02081.html#a20c3f4fd0d84ab59b1ee00494a62ffd0", null ],
    [ "get_description", "a02081.html#ac3c0fcb247b70c6f6a37b8c37b4e1863", null ],
    [ "get_extensions", "a02081.html#a58ed321267dab25305b4607985ec16d1", null ],
    [ "write", "a02081.html#a7c0818a63926bdb439044a8f4c038d85", null ],
    [ "write", "a02081.html#ae0aa2050e93f96d71ff70ce788a76a94", null ]
];