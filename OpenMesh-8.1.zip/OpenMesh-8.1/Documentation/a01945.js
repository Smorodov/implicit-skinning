var a01945 =
[
    [ "HalfedgeT", "a01953.html", "a01953" ],
    [ "VertexT", "a01949.html", "a01949" ],
    [ "VertexAttributes", "a01945.html#a696510997f1c2c6cbf7975b6c40680d8a280bd81e822c54a399c456c33ae33d6a", null ],
    [ "HalfedgeAttributes", "a01945.html#ade66067117a028dadbd6f6fcba57b7fea8c7256fe39a9e1c7c1c4f575d41bb5bf", null ],
    [ "EdgeAttributes", "a01945.html#a5dba7fdbbf973741699dbaf23e5a3af2a3d0f87ea6484042f07e454de28fa3ee7", null ],
    [ "FaceAttributes", "a01945.html#af645df2c785f75d7280ee8b928e8037fa6ec33ccb10890282c62046d47663a38e", null ]
];