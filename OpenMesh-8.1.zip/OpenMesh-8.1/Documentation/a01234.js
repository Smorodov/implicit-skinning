var a01234 =
[
    [ "KernelT", "a01877.html", "a01877" ],
    [ "MeshItems", "a01857.html", [
      [ "EdgeT", "a01869.html", "a01869" ],
      [ "FaceT", "a01873.html", "a01873" ],
      [ "HalfedgeT", "a01865.html", "a01865" ],
      [ "VertexT", "a01861.html", "a01861" ]
    ] ]
];